# -*- coding: utf-8 -*-
import openai
import pandas as pd
from tqdm import tqdm
import random
import time



def generate_answer(text, key='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'):
    openai.api_key = key
    # system_content = '''请给下面文本总结成一个标题,同时提取若干个问答对，最后输出格式为json，格式如下：{"title":"XX","qas":[{"question": "xx", "answer": "xx"},{"question": "xx", "answer": "xx"}]}。请严格按照格式输出。输入的文本以<>分隔'''
    system_content = '''请给下列的文本提取出知识图谱三元组，重点关注文本中的中医概念、诊断、治疗，并输出json格式，格式如下：[{'head':XXX, 'rel':XXX, 'tail':XXX}, {'head':XXX, 'rel':XXX, 'tail':XXX} ……]。请严格按照格式输出。输入的文本以<>分隔，不需要输出其他不相关内容。'''
    user_content = '''以下是输入的文本，<{0}>'''.format(text)

    messages = [
        {"role": "system", "content": system_content},
        {"role": "user", "content": user_content}]

    completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages,
        temperature=0.7
    )
    res_msg = completion.choices[0].message
    return res_msg["content"].strip()



# path = 'data/raw/shanghan_jiangyi.csv'
path = 'csv/all_blank.csv'
df = pd.read_csv(path, encoding='gb18030')[5632:]
output_list = []
# for row_index, row_data in tqdm(df.iterrows(), total=len(df)):
#     user_input = row_data['文档']
#     try:
#         output = chat_model(user_input)
#     except:
#         print('提取失败')
#         output = ''
#
#     output_list.append(output)

for row_index, row_data in tqdm(df.iterrows(), total=len(df)):
    user_input = row_data['文档'][0:1000]

    while True:
        try:
            output = generate_answer(user_input)
            break
        except:
            print(row_index)
            print('第一轮失败')
            time.sleep(121)
            output = generate_answer(user_input, key='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')
            break

    output_list.append(output)

    qa = pd.DataFrame({'问答对': output_list}, index=[i for i in range(5632, row_index+1)]) # 从0开始则为(0, row_index+1)
    merged_df = pd.concat([df.loc[5632:row_index], qa], axis=1)
    # merged_df = pd.concat([df.loc[0:row_index+1], qa], axis=1) # 从0开始

    merged_df.to_csv('tiqu_4.csv', index=False)
    rand_time = random.randint(31, 61)
    time.sleep(rand_time)


# qa = pd.DataFrame({'问答对':output_list}, index=[i for i in range(0, row_index)])
# merged_df = pd.concat([df, qa], axis=1)
#
# merged_df.to_csv('提取问答对600-695.csv', index=False)

print('完成')